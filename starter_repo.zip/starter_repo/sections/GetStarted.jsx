'use client';

const GetStarted = () => (
  <section>
    Get Started Section
  </section>
);

export default GetStarted;
