'use client';

const Explore = () => (
  <section>
    Explore section
  </section>
);

export default Explore;
