const NewFeatures = () => (
  <div>
    New Features
  </div>
);

export default NewFeatures;
