'use client';

const Footer = () => (
  <footer>
    footer
  </footer>
);

export default Footer;
